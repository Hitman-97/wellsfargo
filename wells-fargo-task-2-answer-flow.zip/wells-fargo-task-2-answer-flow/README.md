# Task 2 Model Answer
Model answer for task 2 of the Wells Fargo Software Development Forage program
